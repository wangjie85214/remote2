# 赞助与支持

如果goInception于你有所帮助，可以激励一下作者以作支持。

您的企业or个人信息将会展示在 `赞助者名单` 中以作感谢。

对于大力赞助的企业与个人，可联系作者将公司或个人logo添加到项目首页，并优先考虑对其需求定制化开发。

<!-- ![支付宝](./images/pay.jpeg)

![微信](./images/wechat.jpeg) -->

<!-- <div>
<img src="https://hanchuanchuan.github.io/goInception/images/pay.jpeg" width="200" height="200" alt="支付宝"/>
<div style="display: inline-block;width: 100px"></div>
<img src="https://hanchuanchuan.github.io/goInception/images/wechat.jpeg" width = "200" height = "200" alt="微信"/>
</div> -->

<div>
<img src="./images/pay.jpeg" width="200" height="200" alt="支付宝">
<div style="display: inline-block;width: 100px"></div>
<img src="./images/wechat.jpeg" width="200" height="200" alt="微信">
</div>



------

## 赞助者名单


------

## 定制化需求

提供定制化服务。

具体事宜请通过邮箱或QQ群联系。

邮箱：`chuanchuanhan@gmail.com`

QQ群：`499262190`
