用于截图中的 Python 3.9 / Elasticsearch 服务端 6.3.0 环境。
包含 elasticsearch 6.8.2 和 urllib3 1.26.20 的通用 Python wheel。

将压缩包上传到服务器，例如 /tmp，然后执行：
cd /tmp
unzip es6-offline.zip
python3 -m pip install --no-index --find-links=/tmp/es6-offline "elasticsearch==6.8.2" "urllib3==1.26.20"
python3 -m pip show elasticsearch urllib3

回到原脚本目录执行：
python3 main.py --only active

安装命令会替换当前 Python 环境中的这两个包；共用环境的程序可能受到影响。
确认脚本正常后，在项目依赖文件中固定这两个版本。
本机已验证离线安装、导入和客户端构造，尚未连接你的 Elasticsearch 服务或验证脚本。
